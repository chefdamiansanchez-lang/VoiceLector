# Lector de Voz

App Android que lee libros (EPUB, PDF, TXT) en voz alta y sigue leyendo
en segundo plano aunque apagues la pantalla o cambies de app.

## Funciones
- Escanea el dispositivo y muestra los libros disponibles con portada (grilla oscura).
- Soporta EPUB, PDF y TXT.
- Lectura en voz alta con el motor TextToSpeech de Android, en un servicio
  en primer plano (sigue leyendo con la app en segundo plano).
- Muestra en pantalla el fragmento que se está leyendo en ese momento.
- Guarda el punto de lectura para continuar donde quedaste.

## Cómo subir el proyecto a GitHub y compilar el APK automáticamente

### 1. Crear el repositorio en GitHub
Entrá a https://github.com/new, creá un repositorio (por ejemplo `lector-voz-app`), **sin** agregar README ni .gitignore (ya vienen en este zip).

### 2. Descomprimir y subir el proyecto
Desde una PC con `git` instalado, dentro de la carpeta descomprimida:

```bash
git init
git add .
git commit -m "Primera versión: Lector de Voz"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/lector-voz-app.git
git push -u origin main
```

### 3. Compilación automática (GitHub Actions)
Al hacer `push`, el workflow `.github/workflows/build-apk.yml` se dispara solo:
compila el proyecto y genera el APK debug.

### 4. Descargar el APK ya compilado a tu celular
1. En GitHub, andá a la pestaña **Actions** de tu repo.
2. Entrá a la ejecución más reciente (la que corrió después del push).
3. Bajá hasta **Artifacts** y descargá `LectorVoz-debug-apk` (es un .zip que contiene el `.apk`).
4. Abrí ese .zip desde el celular (o pasalo por WhatsApp/Drive/email) y extraé el `app-debug.apk`.
5. Tocá el archivo `.apk` para instalarlo. Si Android te avisa "orígenes desconocidos",
   permitilo para esa instalación puntual.
6. El ícono "Lector de Voz" va a aparecer en el cajón de apps, listo para abrir.

### Volver a compilar tras hacer cambios
Cada vez que quieras actualizar la app:
```bash
git add .
git commit -m "Descripción del cambio"
git push
```
GitHub vuelve a compilar solo y te deja el nuevo APK en **Actions → Artifacts**.

## Permisos que pide la app
- Acceso a archivos del dispositivo (para encontrar tus libros).
- Notificaciones (para mostrar el control de lectura mientras suena en segundo plano).
