package com.usuario.lectorvoz.data

import android.graphics.Bitmap
import android.net.Uri

enum class BookFormat { EPUB, PDF, TXT, UNKNOWN }

data class Book(
    val uri: Uri,
    val title: String,
    val format: BookFormat,
    val cover: Bitmap? = null,
    val sizeBytes: Long = 0L
)
