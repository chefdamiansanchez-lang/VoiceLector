package com.usuario.lectorvoz.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    title: String,
    currentSnippet: String,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit
) {
    Scaffold(
        containerColor = BackgroundDeep,
        topBar = {
            TopAppBar(
                title = { Text(title, color = TextPrimary, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDeep)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Brush.verticalGradient(listOf(BackgroundDeep, SurfaceElevated)))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            // "Vinilo" estilizado como libro abierto, gira sutilmente mientras lee
            Box(
                Modifier
                    .size(180.dp)
                    .clip(RoundedCornerShape(90.dp))
                    .background(Brush.radialGradient(listOf(AccentViolet, SurfaceElevated))),
                contentAlignment = Alignment.Center
            ) {
                Text("🎧📖", fontSize = 48.sp)
            }

            Spacer(Modifier.height(32.dp))

            Text(
                "Leyendo ahora:",
                color = TextSecondary,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceElevated)
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    currentSnippet.ifBlank { "Preparando texto…" },
                    color = TextPrimary,
                    fontSize = 16.sp,
                    lineHeight = 24.sp
                )
            }

            Spacer(Modifier.height(24.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledIconButton(
                    onClick = onStop,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = SurfaceElevated)
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = "Detener", tint = TextPrimary)
                }

                FilledIconButton(
                    onClick = if (isPlaying) onPause else onPlay,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = AccentAmber)
                ) {
                    Icon(
                        if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pausar" else "Reproducir",
                        tint = BackgroundDeep,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(Modifier.size(48.dp))
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
