package com.usuario.lectorvoz.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.zip.ZipFile

/**
 * EPUB es un .zip con archivos XHTML adentro. Para no depender de
 * librerías externas pesadas, lo recorremos con java.util.zip y limpiamos
 * las etiquetas HTML a mano para quedarnos con el texto plano a leer.
 */
object EpubParser {

    fun extractText(file: File): String {
        val sb = StringBuilder()
        ZipFile(file).use { zip ->
            val entries = zip.entries().toList()
                .filter { it.name.endsWith(".xhtml") || it.name.endsWith(".html") || it.name.endsWith(".htm") }
                .sortedBy { it.name } // orden aproximado de lectura

            for (entry in entries) {
                val raw = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
                sb.append(stripHtml(raw))
                sb.append("\n\n")
            }
        }
        return sb.toString().trim()
    }

    fun extractCover(file: File): Bitmap? {
        return try {
            ZipFile(file).use { zip ->
                val coverEntry = zip.entries().toList().firstOrNull { entry ->
                    val n = entry.name.lowercase()
                    n.contains("cover") && (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png"))
                } ?: return null
                val bytes = zip.getInputStream(coverEntry).readBytes()
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun stripHtml(html: String): String {
        return html
            .replace(Regex("(?is)<script.*?</script>"), " ")
            .replace(Regex("(?is)<style.*?</style>"), " ")
            .replace(Regex("(?is)<br\\s*/?>"), "\n")
            .replace(Regex("(?is)</p>"), "\n\n")
            .replace(Regex("(?is)<.*?>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }
}
