package com.usuario.lectorvoz.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "reading_progress")

/**
 * Guarda y recupera, por cada libro (identificado por su URI), la posición
 * de lectura (índice de caracter dentro del texto extraído) para poder
 * continuar exactamente donde se dejó.
 */
class ProgressStore(private val context: Context) {

    private fun keyFor(bookUri: String) = intPreferencesKey("progress_$bookUri")

    suspend fun saveProgress(bookUri: String, charIndex: Int) {
        context.dataStore.edit { prefs ->
            prefs[keyFor(bookUri)] = charIndex
        }
    }

    fun progressFlow(bookUri: String): Flow<Int> =
        context.dataStore.data.map { prefs -> prefs[keyFor(bookUri)] ?: 0 }
}
