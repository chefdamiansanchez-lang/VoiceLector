package com.usuario.lectorvoz.data

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.core.net.toUri
import com.usuario.lectorvoz.util.EpubParser
import java.io.File

/**
 * Escanea el almacenamiento del dispositivo en busca de libros compatibles
 * (EPUB, PDF, TXT) y arma la lista para mostrar en la pantalla principal.
 */
class BookRepository(private val context: Context) {

    private val supportedExtensions = setOf("epub", "pdf", "txt")

    fun scanDeviceForBooks(): List<Book> {
        val roots = listOfNotNull(
            Environment.getExternalStorageDirectory(),
            context.getExternalFilesDir(null)
        )
        val found = mutableListOf<Book>()
        roots.forEach { root -> walk(root, found, depth = 0) }
        return found.distinctBy { it.uri }
    }

    private fun walk(dir: File, acc: MutableList<Book>, depth: Int) {
        if (depth > 6 || !dir.isDirectory) return
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                walk(f, acc, depth + 1)
            } else {
                val ext = f.extension.lowercase()
                if (ext in supportedExtensions) {
                    acc.add(buildBook(f))
                }
            }
        }
    }

    private fun buildBook(file: File): Book {
        val format = when (file.extension.lowercase()) {
            "epub" -> BookFormat.EPUB
            "pdf" -> BookFormat.PDF
            "txt" -> BookFormat.TXT
            else -> BookFormat.UNKNOWN
        }
        val cover = if (format == BookFormat.EPUB) {
            runCatching { EpubParser.extractCover(file) }.getOrNull()
        } else null

        return Book(
            uri = file.toUri(),
            title = file.nameWithoutExtension,
            format = format,
            cover = cover,
            sizeBytes = file.length()
        )
    }
}
