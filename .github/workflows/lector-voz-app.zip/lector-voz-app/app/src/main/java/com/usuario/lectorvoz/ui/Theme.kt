package com.usuario.lectorvoz.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BackgroundDeep = Color(0xFF0B0B12)
val SurfaceElevated = Color(0xFF16161F)
val AccentAmber = Color(0xFFE8A33D)
val AccentViolet = Color(0xFF8E6BFF)
val TextPrimary = Color(0xFFF4F1EA)
val TextSecondary = Color(0xFF9C97A8)

private val DarkColors = darkColorScheme(
    background = BackgroundDeep,
    surface = SurfaceElevated,
    primary = AccentAmber,
    secondary = AccentViolet,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
)

@Composable
fun LectorVozTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}
