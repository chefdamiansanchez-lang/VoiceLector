package com.usuario.lectorvoz.util

import android.content.Context
import com.usuario.lectorvoz.data.BookFormat
import java.io.File

object TextExtractor {

    fun extract(context: Context, file: File, format: BookFormat): String {
        return when (format) {
            BookFormat.EPUB -> EpubParser.extractText(file)
            BookFormat.PDF -> PdfTextExtractor.extractText(context, file)
            BookFormat.TXT -> file.readText(Charsets.UTF_8)
            BookFormat.UNKNOWN -> ""
        }
    }
}
