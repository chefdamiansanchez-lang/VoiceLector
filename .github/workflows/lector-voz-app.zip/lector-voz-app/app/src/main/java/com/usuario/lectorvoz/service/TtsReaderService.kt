package com.usuario.lectorvoz.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.usuario.lectorvoz.MainActivity
import com.usuario.lectorvoz.R
import com.usuario.lectorvoz.data.ProgressStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

/**
 * Foreground service: mantiene vivo el motor TextToSpeech aunque el usuario
 * apague la pantalla o cambie de app. Lee el libro en trozos (chunks) para
 * poder ir guardando el progreso y permitir pausar/reanudar con precisión.
 */
class TtsReaderService : Service() {

    companion object {
        const val CHANNEL_ID = "lectura_en_curso"
        const val NOTIFICATION_ID = 1

        const val ACTION_START = "com.usuario.lectorvoz.action.START"
        const val ACTION_PAUSE = "com.usuario.lectorvoz.action.PAUSE"
        const val ACTION_STOP = "com.usuario.lectorvoz.action.STOP"

        const val EXTRA_BOOK_URI = "extra_book_uri"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_START_INDEX = "extra_start_index"

        private const val CHUNK_SIZE = 400 // caracteres por utterance
    }

    private var tts: TextToSpeech? = null
    private lateinit var progressStore: ProgressStore
    private val scope = CoroutineScope(Dispatchers.Main)

    private var fullText: String = ""
    private var chunks: List<String> = emptyList()
    private var currentChunkIndex = 0
    private var currentBookUri: String = ""
    private var currentTitle: String = ""
    private var isPaused = false

    override fun onCreate() {
        super.onCreate()
        progressStore = ProgressStore(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                currentBookUri = intent.getStringExtra(EXTRA_BOOK_URI) ?: return START_NOT_STICKY
                currentTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Libro"
                fullText = intent.getStringExtra(EXTRA_TEXT) ?: ""
                val startIndex = intent.getIntExtra(EXTRA_START_INDEX, 0)
                startForeground(NOTIFICATION_ID, buildNotification("Preparando lectura…"))
                prepareAndStart(startIndex)
            }
            ACTION_PAUSE -> pauseReading()
            ACTION_STOP -> stopReading()
        }
        return START_NOT_STICKY
    }

    private fun prepareAndStart(startIndex: Int) {
        chunks = splitIntoChunks(fullText, CHUNK_SIZE)
        currentChunkIndex = indexOfChunkContaining(startIndex)

        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        onChunkFinished()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onChunkFinished()
                    }
                })
                speakCurrentChunk()
            }
        }
    }

    private fun onChunkFinished() {
        if (isPaused) return
        currentChunkIndex++
        saveProgress()
        if (currentChunkIndex < chunks.size) {
            speakCurrentChunk()
        } else {
            stopReading()
        }
    }

    private fun speakCurrentChunk() {
        val chunk = chunks.getOrNull(currentChunkIndex) ?: return
        updateNotification(chunk.take(60) + "…")
        tts?.speak(chunk, TextToSpeech.QUEUE_FLUSH, null, "chunk_$currentChunkIndex")
    }

    private fun pauseReading() {
        isPaused = true
        tts?.stop()
        saveProgress()
        updateNotification("Pausado")
    }

    private fun stopReading() {
        saveProgress()
        tts?.stop()
        tts?.shutdown()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun saveProgress() {
        val charIndex = chunks.take(currentChunkIndex).sumOf { it.length }
        scope.launch {
            progressStore.saveProgress(currentBookUri, charIndex)
        }
    }

    private fun indexOfChunkContaining(charIndex: Int): Int {
        var acc = 0
        chunks.forEachIndexed { i, c ->
            acc += c.length
            if (acc >= charIndex) return i
        }
        return 0
    }

    private fun splitIntoChunks(text: String, size: Int): List<String> {
        if (text.isEmpty()) return emptyList()
        val result = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            var end = minOf(start + size, text.length)
            // evitar cortar una palabra a la mitad
            if (end < text.length) {
                val lastSpace = text.lastIndexOf(' ', end)
                if (lastSpace > start) end = lastSpace
            }
            result.add(text.substring(start, end))
            start = end
        }
        return result
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lectura en voz alta",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(currentTitle)
            .setContentText(status)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(status: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(status))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
