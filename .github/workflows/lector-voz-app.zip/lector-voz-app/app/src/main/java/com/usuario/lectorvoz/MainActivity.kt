package com.usuario.lectorvoz

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.net.toUri
import com.usuario.lectorvoz.data.Book
import com.usuario.lectorvoz.data.BookFormat
import com.usuario.lectorvoz.data.BookRepository
import com.usuario.lectorvoz.data.ProgressStore
import com.usuario.lectorvoz.service.TtsReaderService
import com.usuario.lectorvoz.ui.BookListScreen
import com.usuario.lectorvoz.ui.LectorVozTheme
import com.usuario.lectorvoz.ui.ReaderScreen
import com.usuario.lectorvoz.util.TextExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var repository: BookRepository
    private lateinit var progressStore: ProgressStore

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* el escaneo se reintenta al volver a primer plano */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = BookRepository(applicationContext)
        progressStore = ProgressStore(applicationContext)
        requestStoragePermissionIfNeeded()

        setContent {
            LectorVozTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavHost()
                }
            }
        }
    }

    private fun requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
            permissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    @Composable
    private fun AppNavHost() {
        var books by remember { mutableStateOf<List<Book>>(emptyList()) }
        var isLoading by remember { mutableStateOf(true) }
        var selectedBook by remember { mutableStateOf<Book?>(null) }
        var currentSnippet by remember { mutableStateOf("") }
        var isPlaying by remember { mutableStateOf(false) }
        var extractedText by remember { mutableStateOf("") }

        val scope = rememberCoroutineScope()

        LaunchedEffect(Unit) {
            withContext(Dispatchers.IO) {
                val found = repository.scanDeviceForBooks()
                books = found
                isLoading = false
            }
        }

        val current = selectedBook
        if (current == null) {
            BookListScreen(
                books = books,
                isLoading = isLoading,
                onBookSelected = { book ->
                    selectedBook = book
                    scope.launch {
                        val file = File(book.uri.path ?: return@launch)
                        val text = withContext(Dispatchers.IO) {
                            TextExtractor.extract(applicationContext, file, book.format)
                        }
                        extractedText = text
                        currentSnippet = text.take(500)
                    }
                }
            )
        } else {
            ReaderScreen(
                title = current.title,
                currentSnippet = currentSnippet,
                isPlaying = isPlaying,
                onBack = {
                    stopService(Intent(this@MainActivity, TtsReaderService::class.java))
                    isPlaying = false
                    selectedBook = null
                },
                onPlay = {
                    scope.launch {
                        val savedIndex = progressStore.progressFlow(current.uri.toString()).first()
                        val intent = Intent(this@MainActivity, TtsReaderService::class.java).apply {
                            action = TtsReaderService.ACTION_START
                            putExtra(TtsReaderService.EXTRA_BOOK_URI, current.uri.toString())
                            putExtra(TtsReaderService.EXTRA_TITLE, current.title)
                            putExtra(TtsReaderService.EXTRA_TEXT, extractedText)
                            putExtra(TtsReaderService.EXTRA_START_INDEX, savedIndex)
                        }
                        startForegroundService(intent)
                        isPlaying = true
                    }
                },
                onPause = {
                    val intent = Intent(this@MainActivity, TtsReaderService::class.java).apply {
                        action = TtsReaderService.ACTION_PAUSE
                    }
                    startService(intent)
                    isPlaying = false
                },
                onStop = {
                    val intent = Intent(this@MainActivity, TtsReaderService::class.java).apply {
                        action = TtsReaderService.ACTION_STOP
                    }
                    startService(intent)
                    isPlaying = false
                }
            )
        }
    }
}
