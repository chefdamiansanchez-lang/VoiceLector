package com.usuario.lectorvoz.util

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

object PdfTextExtractor {

    private var loaded = false

    fun extractText(context: Context, file: File): String {
        if (!loaded) {
            PDFBoxResourceLoader.init(context.applicationContext)
            loaded = true
        }
        PDDocument.load(file).use { doc ->
            val stripper = PDFTextStripper()
            return stripper.getText(doc).trim()
        }
    }
}
